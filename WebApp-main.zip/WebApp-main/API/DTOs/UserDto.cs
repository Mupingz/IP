﻿using System;

namespace API.DTOs;
#nullable disable
public class UserDto
{
    public string Username { get; set; }
    public string Token { get; set; }
}
